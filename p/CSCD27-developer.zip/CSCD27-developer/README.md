This is for D27
